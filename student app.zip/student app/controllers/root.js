var bcryptjs = require('bcryptjs')
var jwt = require('jsonwebtoken')

var Teacher = require('../models/teacher')
var Student = require('../models/student')
var Reclamation = require('../models/reclamation')
var Note = require('../models/note')

exports.index = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            if (err.message == 'jwt expired'){
                res.status(200).redirect('/logout')    
            }
            res.status(200).render('home')
        } else {
            res.locals.user = data

            res.status(200).render('home')
        }
    })
}

exports.about = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            res.status(200).render('about')
        } else {
            res.locals.user = data
            res.status(200).render('about')
        }
    })
}

exports.dashboard = (req , res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')

        } else {
            if (data.teacher) {

                resp = data.teacher.isResp
                if (resp == 0) {
                    res.locals.user = data
                    res.locals.nmbrRec = req.cookies['nmbrRec']

                    if (req.query.u == 1)
                        req.flash('info', 'account updated')

                    res.render('teacher/home')
                } else {
                    res.locals.user = data
                    res.locals.nmbrRec = req.cookies['nmbrRec']

                    if (req.query.u == 1)
                        req.flash('info', 'account updated')

                    res.render('responsible/home')
                }
            }else{
                if(data.student){
                    res.locals.user = data
                    if (req.query.u == 1)
                        req.flash('info', 'account updated')
                    res.render('student/home')
                }
            }

        }
    })
}

exports.login_page = (req, res) => {
    res.status(200).render('login')
}

exports.login = (req, res) => {

    req.checkBody('username', 'username is required').notEmpty()
    req.checkBody('password', 'password is required').notEmpty()

    var errors = req.validationErrors()
    var username = req.body.username
    var password = req.body.password
    var role = req.body.radio

    
    if (errors) {
        console.log('******************'+errors)
        //req.flash('danger',errors)
        res.render('login',{errors:errors,user:null})
    }else{

        if (role == 'admin') {
            query = { username: username }
            Teacher.findOne(query, (err, teacher) => {
                if (err) {
                    req.flash('warning', 'internal server error...try again later plz !')
                    res.status(500).redirect('/')
                }
                if (teacher == null) {
                    req.flash('danger', 'no username found !!')
                    res.status(404).redirect('/login')
                }
                else {
                    bcryptjs.compare(password, teacher.password, (err, isEqual) => {
                        if (err) {
                            req.flash('warning', 'internal server error...try again later plz !')
                            res.status(500).redirect('/login')
                        }
                        if (isEqual) {
                            if (teacher.isResp == 1) {
                                Reclamation.find({ owner: "responsible" }, (err, reclamations) => {
    
                                    if (err) {
                                        req.flash('warning', 'internal server error...try again later plz !')
                                        res.status(500).redirect('/')
                                    }
                                    else {
                                        jwt.sign({ teacher }, 'secretkey', { expiresIn: '4h' },(err, token) => {
                                            req.flash('info', 'you are now loged in...')
                                            res.cookie('token', token)
                                            nbr = reclamations.length
                                            res.cookie('nmbrRec', nbr)
                                            res.status(200).redirect('/dashboard')
                                        })
                                    }
                                })
                            } else {
    
                                Reclamation.find({ owner: "teacher", to: teacher.fullname }, (err, reclamations) => {
    
                                    if (err) {
                                        req.flash('warning', 'internal server error...try again later plz !')
                                        res.status(500).redirect('/')
                                    }
                                    else {
                                        jwt.sign({ teacher }, 'secretkey', { expiresIn: '3h' },(err, token) => {
                                            req.flash('info', 'you are now loged in...')
                                            res.cookie('token', token)
                                            nbr = reclamations.length
                                            res.cookie('nmbrRec', nbr)
                                            res.status(200).redirect('/dashboard')
                                        })
                                    }
                                })
                            }
                        } else {
                            req.flash('danger', 'wrong password...try again !')
                            res.status(401).redirect('/login')
                        }
                    })
                }
            })
        } else {
            if (role == 'student') {
                query = { username: username }
                Student.findOne(query, (err, student) => {
                    if (err) {
                        req.flash('warning', 'internal server error...try again later plz !')
                        res.status(500).redirect('/')
                    }
                    if (student == null) {
                        req.flash('danger', 'no username found !!')
                        res.status(404).redirect('/login')
                    }
                    else {
                        bcryptjs.compare(password, student.password, (err, isEqual) => {
                            if (err) {
                                req.flash('warning', 'internal server error...try again later plz !')
                                res.status(500).redirect('/login')
                            } else {
                                if (isEqual) {
                                    jwt.sign({ student }, 'secretkey', { expiresIn: '1h' },(err, token) => {
                                        req.flash('info', 'you are now loged in...')
                                        res.cookie('token', token)
                                        res.status(200).redirect('/dashboard')
                                    })
                                } else {
                                    req.flash('danger', 'wrong password...try again !')
                                    res.status(401).redirect('/login')
                                }
                            }
                        })
                    }
                })
            }
        }
    }

}

exports.logout = (req, res) => {
    req.session.student = null
    req.session.teacher = null
    req.session.responsible = null
    req.session.nbmrRec = null
    res.locals.nmbrRec = null

    res.clearCookie('token')
    res.clearCookie('nmbrRec')

    req.flash('info', 'you are now logged out !')
    res.status(200).redirect('/')
}

exports.students = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in ')
            res.redirect('/')
        } else {
            if (data.student) {
                req.flash('danger', 'you dont have permission')
                res.redirect('/')
            }
            if(data.teacher.isResp==1){

                // res.setHeader('Authorization', req.token)
                res.locals.user = data
                res.locals.nmbrRec = req.cookies['nmbrRec']
    
                Student.find({}, (err, students) => {
                    if (err) {
                        req.flash('warning', 'internal server error...try again later plz !')
                        res.status(500).redirect('/dashboard')
                    }
                    else {
                        if (req.query.u == 1)
                            req.flash('success', 'student updated...')
                        if (req.query.d == 1)
                            req.flash('info', 'student deleted...')
    
                        res.status(200).render('responsible/students', {
                            students: students
                        })
                    }
                })
            } else {
                // res.setHeader('Authorization', req.token)
                res.locals.user = data
                res.locals.nmbrRec = req.cookies['nmbrRec']

                Student.find({}, (err, students) => {
                    if (err) throw err
                    else {
                        var Etu_notes = []
                        Note.find({ module: data.teacher.codeModule }, (err, notes) => {
                            for (var i = 0; i < students.length; i++) {
                                Etu_notes[i] = { note: 'N/A' }
                                for (var j = 0; j < notes.length; j++) {
                                    if (notes[j].id_student == students[i].id) {
                                        Etu_notes[i] = {
                                            id: notes[j].id,
                                            note: notes[j].value
                                        }
                                        break
                                    }
                                }
                            }
                            // console.log(notes)
                            // console.log(Etu_notes)
                            if (req.query.u == 1)
                                req.flash('success', 'note updated...')
                            if (req.query.d == 1)
                                req.flash('info', 'note deleted...')

                            res.render('teacher/students', {
                                students: students,
                                notes: Etu_notes
                            })

                        })

                    }
                })
            }
            
        }
    })
}

exports.teachers = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if(data.teacher){
                res.locals.user = data
                res.locals.nmbrRec = req.cookies['nmbrRec']
    
                var query = { isResp: 0 }
                Teacher.find(query, (err, teachers) => {
                    if (err) {
                        req.flash('warning', 'internal server error...try again later plz !')
                        res.status(500).redirect('/dashboard')
                    }
                    else {
                        if (req.query.u == 1)
                            req.flash('success', 'teacher updated...')
                        if (req.query.d == 1)
                            req.flash('info', 'teacher deleted...')
    
                        res.status(200).render('responsible/teachers', {
                            teachers: teachers
                        })
                    }
                })
            }else{
                if(data.student){

                    res.locals.user = data
                    Teacher.find({ isResp: 0 }, (err, teachers) => {
                        if (err) throw err
                        else {
                            res.render('student/teachers', {
                                teachers: teachers
                            })
                        }
                    })
                }
            }
        }
    })
}

exports.reclamations = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if (data.student) {
                req.flash('danger','you dont have permission')
                res.redirect('/')
            }
            if (data.teacher.isResp == 1) {
                res.locals.user = data

                var query = { owner: "responsible" }
                Reclamation.find(query, (err, reclamations) => {
                    if (err) {
                        req.flash('warning', 'internal server error...try again later plz !')
                        res.status(500).redirect('/dashboard')
                    } else {
                        nbr = reclamations.length
                        res.cookie('nmbrRec', nbr)
                        res.locals.nmbrRec = req.cookies['nmbrRec']

                        if (req.query.d == 1)
                            req.flash('info', 'reclamation deleted...')

                        res.status(200).render('responsible/reclamations',
                            {
                                reclamations: reclamations
                            })
                    }
                })
            } else {
                res.locals.user = data
                res.locals.nmbrRec = req.cookies['nmbrRec']
                console.log(res.locals.nmbrRec)

                var query = { owner: "teacher", to: data.teacher.fullname }
                Reclamation.find(query, (err, reclamations) => {
                    if (err) {
                        console.log(err)
                    } else {
                        nbr = reclamations.length
                        res.cookie('nmbrRec', nbr)
                        res.locals.nmbrRec = req.cookies['nmbrRec']

                        res.render('teacher/reclamations',
                            {
                                reclamations: reclamations
                            })
                    }
                })
            }
            // res.setHeader('Authorization', req.token)

        }
    })
}

exports.notes = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if (data.teacher) {
                req.flash('danger', 'you dont have permission')
                res.redirect('/')
            }
            res.locals.user = data

            var query = { id_student: data.student._id }
            Note.find().sort('module').find(query, (err, notes) => {
                if (err) throw err
                else {
                    var sum=0
                    for(var i=0;i<notes.length;i++){
                        sum=sum+notes[i].value
                    }
                    if(i==6){
                        var moy = sum / 5
                        notes.push({moy:moy})
                    }
                    
                    console.log(notes)

                    res.render('student/notes', {
                        notes: notes
                    })
                }
            })
        }
    })
}

exports.actualities = (req, res)=>{
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if(data.teacher){
                if(data.teacher.isResp==1){

                    res.locals.user = data
        
                    var query = { name: "admin" }
                    Reclamation.find(query, (err, actualities) => {
                        if (err) {
                            req.flash('warning', 'internal server error...try again later plz !')
                            res.status(500).redirect('/dashboard')
                        } else {
                            // nbr = reclamations.length
                            // res.cookie('nmbrRec', nbr)
                            res.locals.nmbrRec = req.cookies['nmbrRec']
        
                            if (req.query.d == 1)
                                req.flash('info', 'actuality deleted...')
                            if (req.query.u == 1)
                                req.flash('info', 'actuality updated...')    
        
                            res.status(200).render('responsible/actualities',
                                {
                                    actualities: actualities
                                })
                        }
                    })
                }else{
                    res.locals.user = data

                    var query = { name: "admin",to:"teachers" }
                    Reclamation.find(query, (err, actualities) => {
                        if (err) {
                            req.flash('warning', 'internal server error...try again later plz !')
                            res.status(500).redirect('/dashboard')
                        } else {
                            // nbr = reclamations.length
                            // res.cookie('nmbrRec', nbr)
                            res.locals.nmbrRec = req.cookies['nmbrRec']

                            
                            res.status(200).render('teacher/actualities',
                                {
                                    actualities: actualities
                                })
                        }
                    })
                }
            }else{
                if(data.student){
                    res.locals.user = data

                    var query = { name: "admin", to: "students" }
                    Reclamation.find(query, (err, actualities) => {
                        if (err) {
                            req.flash('warning', 'internal server error...try again later plz !')
                            res.status(500).redirect('/dashboard')
                        } else {
                            
                            res.status(200).render('student/actualities',
                                {
                                    actualities: actualities
                                })
                        }
                    })
                }
            }
            

        }
    })
}

exports.pv = (req , res,next)=>{
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')

        }else{
            if(!data.student){

                res.locals.user = data
                res.locals.nmbrRec = req.cookies['nmbrRec']
                
                Student.find().sort('fullname').find({},(err, students)=>{
                    if(err) throw err
                    else{
                        Note.find().sort('module').find({}, (err, notes) => {
                            if (err) {
                                console.log(err)
                            } else {
                                etu_note=[]
            
                                notess = []
            
                                for(var i=0;i<students.length;i++){
                                    //etu_note[i] = students[i].fullname
                                    et = students[i]._id + ""
                                    for(var j=0;j<notes.length;j++){
                                        
                                        n = notes[j].id_student+""
                                        if(et === n){
                                            
                                            notess.push({
                                                module: notes[j].module,
                                                value: notes[j].value
                                            })
                                            
                                            
                                            //console.log(notes[j].value)
            
                                        }
                                    }
                                    etu_note.push({
                                        name:students[i].fullname,
                                        notes:notess
                                    
                                    })
                                    notess=[]
                                }
                                
                                console.log(etu_note[0].notes[1])
                                res.render('responsible/pv',{notes:etu_note})
                                // res.json({notes: etu_note })
                            }
                        })
            
                    }
                })
            }else{
                req.flash('danger', 'you dont have permission')
                res.redirect('/')
            }
        }
    })   

}

exports.edit_account = (req , res)=>{
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if(data.teacher){
                res.locals.user = data
                res.locals.nmbrRec = req.cookies['nmbrRec']
                
                res.render('responsible/edit_account',{username:data.teacher.username})
            }
        }
    })
}

exports.put_account = (req , res) =>{
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        }else{

            var password = req.body.password
            var username = req.body.username
            var confirm = req.body.confirm

            if(password == confirm){

                if(data.teacher){
    
                    var query = { username: username }
                    Teacher.find(query, (err, teachers) => {
                        if (err) {
                            req.flash('warning', 'internal server error...try again later plz !')
                            res.status(500).redirect(303,'/dashboard')
                        }
                        if (teachers.length) {
                            console.log('exist')
                            req.flash('warning', 'username already exist try another one plz')
                            res.status(204).redirect(303,'/dashboard')
                        } else {
        
                            bcryptjs.genSalt(10, (err, salt) => {
                                bcryptjs.hash(password, salt, (err, hash) => {
                                    if (err) {
                                        console.log(err)
                                        req.flash('warning', 'internal server error...try again later plz !')
                                        res.status(500).redirect('/dashboard')
                                    } else {
                                        var teacher = {}
                                        teacher.username = username
                                        teacher.password = hash
        
                                        console.log(data.teacher._id)
                                        
                                        Teacher.update({_id:data.teacher._id},teacher,function (err) {
                                            if (err) {
                                                console.log('error')
                                                req.flash('warning', 'internal server error...try again later plz !')
                                                res.status(500).redirect('/dashboard')
                                            } else {
                                                console.log('ok')
                                                req.flash('success', 'account updated with succeess')
                                                res.status(200).redirect(303,'/dashboard')
                                            }
                                        })
                                    }
                
                                })
                            })
                        }
                    })    
                }else{
                    if(data.student){
                        var query = { username: username }
                        Student.find(query, (err, students) => {
                            if (err) {
                                req.flash('warning', 'internal server error...try again later plz !')
                                res.status(500).redirect(303, '/dashboard')
                            }
                            if (students.length) {
                                console.log('exist')
                                req.flash('warning', 'username already exist try another one plz')
                                res.status(204).redirect(303, '/dashboard')
                            } else {
    
                                bcryptjs.genSalt(10, (err, salt) => {
                                    bcryptjs.hash(password, salt, (err, hash) => {
                                        if (err) {
                                            console.log(err)
                                            req.flash('warning', 'internal server error...try again later plz !')
                                            res.status(500).redirect('/dashboard')
                                        } else {
                                            var student = {}
                                            student.username = username
                                            student.password = hash
    
                                            console.log(data.student._id)
    
                                            Student.update({ _id: data.student._id }, student, function (err) {
                                                if (err) {
                                                    console.log('error')
                                                    req.flash('warning', 'internal server error...try again later plz !')
                                                    res.status(500).redirect('/dashboard')
                                                } else {
                                                    console.log('ok')
                                                    req.flash('success', 'account updated with succeess')
                                                    res.status(200).redirect(303, '/dashboard')
                                                }
                                            })
                                        }
    
                                    })
                                })
                            }
                        })
                    }
                }
            }else{
                req.flash('warning','wrong confirmation...try again plz')
                res.redirect(303,'/account')
            }

        }    
    })
}
