var bcryptjs = require('bcryptjs')
var jwt = require('jsonwebtoken')

var Teacher = require('../models/teacher')

exports.add_teacher = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if (data.student || data.teacher.isResp ==0) {
                req.flash('danger', 'you dont have permission')
                res.redirect('/')
            }
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            res.render('responsible/addTeacher')
        }
    })
}

exports.update_teacher = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if (data.student || data.teacher.isResp == 0) {
                req.flash('danger', 'you dont have permission')
                res.redirect('/')
            }
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            Teacher.findById(req.params.id, (err, teacher) => {
                if (err) {
                    req.flash('warning', 'internal server error...try again later plz !')
                    res.status(500).redirect('/responsible')
                }
                else {
                    res.status(200).render('responsible/updateTeacher', {
                        teacher: teacher
                    })
                }
            })
        }
    })
}

exports.post_teacher = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/dashboard')
        } else {
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            const name = req.body.name
            const username = req.body.username
            const email = req.body.email
            const password = req.body.password
            const confirm = req.body.confirm
            const module = req.body.module

            req.checkBody('name', 'name is required').notEmpty()
            req.checkBody('username', 'username is required').notEmpty()
            req.checkBody('email', 'email is required').notEmpty()
            req.checkBody('email', 'email is not valid').isEmail()
            req.checkBody('password', 'password is required').notEmpty().isLength({ min: 6 })
            req.checkBody('confirm', 'you must confirm password').equals(password)


            var errors = req.validationErrors()

            if(errors){
                res.render('responsible/addTeacher',{
                    errors:errors,
                    user:data,
                    nmbrRec: req.cookies['nmbrRec']
                })
            }else{

                // console.log(teacher)
                var query = { username: username }
                Teacher.find(query, (err, teachers) => {
                    if (err) {
                        req.flash('warning', 'internal server error...try again later plz !')
                        res.status(500).redirect('/responsible')
                    }
                    if (teachers.length) {
                        req.flash('warning', 'username already exist try another one plz')
                        res.status(204).redirect('/teachers')
                    } else {
                        var teacher = new Teacher({
                            fullname: name,
                            username: username,
                            password: password,
                            email: email,
                            codeModule: module
                        })
    
                        bcryptjs.genSalt(10, (err, salt) => {
                            bcryptjs.hash(teacher.password, salt, (err, hash) => {
                                if (err) {
                                    console.log(err)
                                    req.flash('warning', 'internal server error...try again later plz !')
                                    res.status(500).redirect('/dashboard')
                                } else {
                                    teacher.password = hash
                                    teacher.save(function (err) {
                                        if (err) {
                                            req.flash('warning', 'internal server error...try again later plz !')
                                            res.status(500).redirect('/dashboard')
                                        } else {
                                            req.flash('success', 'teacher created with succeess')
                                            res.status(200).redirect('/teachers')
                                        }
                                    })
                                }
    
                            })
                        })
                    }
                })
            }

        }
    })
}

exports.put_teacher = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/dashboard')
        } else {
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            req.checkBody('name', 'name is required').notEmpty()
            req.checkBody('username', 'username is required').notEmpty()
            req.checkBody('email', 'email is required').notEmpty()
            req.checkBody('email', 'email is not valid').isEmail()
            
            var errors = req.validationErrors()

            if(errors){

            }else{

                var teacher = {}
                teacher.fullname = req.body.name
                teacher.username = req.body.username
                teacher.email = req.body.email
                teacher.codeModule = req.body.module
    
                var query = { _id: req.params.id }
                Teacher.update(query, teacher, (err) => {
                    if (err) {
                        console.log(err)
                        req.flash('warning', 'teacher not updated...try again')
                        res.status(500).redirect('/teachers')
                    }
                    else {
                        req.flash('success', 'teacher updated with success')
                        res.redirect(303, '/teachers')
                    }
                })
            }
        }
    })
}

exports.delete_teacher = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/dashboard')
        } else {
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            var query = { _id: req.params.id }
            Teacher.remove(query, (err) => {
                if (err) {
                    req.flash('warning', 'internal server error...try again later plz !')
                    res.status(500).redirect('/dashboard')
                }
                else {
                    req.flash('info', 'teacher deleted..')
                    res.redirect(303, '/teachers')
                }
            })
        }
    })
}