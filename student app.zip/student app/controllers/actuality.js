var jwt = require('jsonwebtoken')

var Reclamation = require('../models/reclamation')

exports.actuality = (req, res)=>{
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            
            res.locals.user = data
            res.render('responsible/actuality')
        }
    })
} 

exports.read_actuality = (req, res)=>{
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
    if (err) {
        console.log(err)
        req.flash('danger', 'you need to be loged in')
        res.redirect('/dashboard')
    } else {
        res.locals.user = data
        res.locals.nmbrRec = req.cookies['nmbrRec']

        Reclamation.findById(req.params.id, (err, actuality) => {
            if (err) {
                req.flash('warning', 'internal server error...try again later plz !')
                res.status(500).redirect('/dashboard')
            } else {
                res.status(200).render('responsible/read_actuality', {
                    actuality: actuality
                })
            }
        })
    }
    })
}

exports.post_actuality = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            res.locals.user = data

            var name = "admin"
            var body = req.body.reclamation_body
            //var owner = req.body.actuality_for
            var to = req.body.actuality_for

            var reclamation = new Reclamation({
                name: name,
                filiere:'null',
                body: body,
                owner:'null',
                to: to
            })

            console.log(reclamation)

            reclamation.save((err) => {
                if (err) {
                    console.log(err)
                    req.flash('warning', 'failed to create actuality...try again ')
                    res.redirect('/actuality')
                } else {
                    req.flash('success', 'actuality created with success...')
                    res.redirect('/actualities')
                }
            })
        }
    })
} 

exports.delete_actuality = (req, res) =>{
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if (data.teacher.isResp == 1) {

                res.locals.user = data
                res.locals.nmbrRec = req.cookies['nmbrRec']

                var query = { _id: req.params.id }
                Reclamation.remove(query, (err) => {
                    if (err) {
                        req.flash('warning', 'internal server error...try again later plz !')
                        res.status(500).redirect('/dashboard')
                    }
                    else {               
                               
                        res.redirect(303, '/actualities')
                    }
                })
            } 
        }
    })
}
