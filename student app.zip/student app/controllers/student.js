var bcryptjs = require('bcryptjs')
var jwt = require('jsonwebtoken')

var Student = require('../models/student')
var Note = require('../models/note')

exports.add_student = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if (data.student || data.teacher.isResp==0) {
                req.flash('danger', 'you dont have permission')
                res.redirect('/')
            }
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            res.render('responsible/addStudent')
        }
    })
}

exports.update_student = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if (data.student || data.teacher.isResp == 0) {
                req.flash('danger', 'you dont have permission')
                res.redirect('/')
            }
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            Student.findById(req.params.id, (err, student) => {
                if (err) {
                    req.flash('warning', 'internal server error...try again later plz !')
                    res.status(500).redirect('/responsible')
                }
                else {
                    res.status(200).render('responsible/updateStudent', {
                        student: student
                    })
                }
            })
        }
    })
}

exports.post_student = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            const name = req.body.name
            const username = req.body.username
            const email = req.body.email
            const password = req.body.password
            const confirm = req.body.confirm
            const filiere = req.body.filiere
            const year = req.body.year

            req.checkBody('name', 'name is required').notEmpty()
            req.checkBody('username', 'username is required').notEmpty()
            req.checkBody('year', 'year is required').notEmpty()
            req.checkBody('filiere', 'filiere is required').notEmpty()
            req.checkBody('email', 'email is required').notEmpty()
            req.checkBody('email', 'email is not valid').isEmail()
            req.checkBody('password', 'password is required').notEmpty().isLength({ min: 6 })
            req.checkBody('confirm', 'you must confirm password').equals(password)


            var errors = req.validationErrors()

            if (errors) {
                res.render('responsible/addStudent', {
                    errors: errors,
                    user: data,
                    nmbrRec: req.cookies['nmbrRec']
                })
            }else{

                // console.log(teacher)
                var query = { username: username }
                Student.find(query, (err, student) => {
                    if (err) {
                        req.flash('warning', 'internal server error...try again later plz !')
                        res.status(500).redirect('/dashboard')
                    }
                    if (student.length) {
                        req.flash('warning', 'username already exist try another one plz')
                        res.render('responsible/addStudent')
                    } else {
                        var student = new Student({
                            fullname: name,
                            username: username,
                            password: password,
                            email: email,
                            filiere: filiere,
                            year: year
                        })
    
                        bcryptjs.genSalt(10, (err, salt) => {
                            bcryptjs.hash(student.password, salt, (err, hash) => {
                                if (err) {
                                    console.log(err)
                                    req.flash('warning', 'internal server error...try again later plz !')
                                    res.status(500).redirect('/dashboard')
                                } else {
                                    student.password = hash
                                    student.save(function (err) {
                                        if (err) {
                                            console.log(err)
                                            req.flash('warning', 'internal server error...try again later plz !')
                                            res.status(500).redirect('/dashboard')
                                        } else {
                                            console.log('student created')
                                            req.flash('success', 'student created with succeess')
                                            res.status(200).redirect('/students')
                                        }
                                    })
                                }
    
                            })
                        })
                    }
                })
            }
        }
    })
}

exports.put_student = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            var student = {}
            student.fullname = req.body.name
            student.username = req.body.username
            student.email = req.body.email
            student.filiere = req.body.filiere
            student.year = req.body.year


            var query = { _id: req.params.id }
            Student.update(query, student, (err) => {
                if (err) {
                    req.flash('warning', 'internal server error...try again later plz !')
                    res.status(500).redirect('/dashboard')
                }
                else {
                    req.flash('success', 'student updated with success')
                    res.redirect(303, '/students')
                }
            })
        }
    })
}

exports.delete_student = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            var query = { _id: req.params.id }
            Student.remove(query, (err) => {
                if (err) {
                    req.flash('warning', 'internal server error...try again later plz !')
                    res.status(500).redirect('/dashboard')
                }
                else {
                    req.flash('info', 'student deleted..')
                    res.redirect(303, '/students')
                }
            })
        }
    })
}

exports.add_note = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if (data.student || data.teacher.isResp==1) {
                req.flash('danger', 'you dont have permission')
                res.redirect('/')
            }
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            var query = { _id: req.params.id }
            Student.findById(query, (err, student) => {
                if (err) throw err
                else {
                    res.render('teacher/addNote', {
                        students: student.fullname
                    })
                }
            })
        }
    })
}

exports.update_note = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if (data.student || data.teacher.isResp == 1) {
                req.flash('danger', 'you dont have permission')
                res.redirect('/')
            }
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            var query = { _id: req.params.id_et }
            Student.findById(query, (err, student) => {
                if (err) throw err
                else {
                    Note.findById(req.params.id, (err, note) => {
                        if (err) console.log(err)
                        else {
                            console.log(note)
                            res.render('teacher/editNote', {
                                note: note,
                                students: student
                            })
                        }
                    })
                }
            })
        }
    })
}

exports.post_note = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            var query = { id_student: req.params.id, module: data.teacher.codeModule }
            Note.find(query, (err, student) => {
                if (err) throw err
                else {
                    if (student.length > 0) {
                        req.flash('warning', 'student already have a note..')
                        res.redirect('/students')
                    } else {
                        Student.findById(req.params.id,(err,student)=>{
                            if(err) throw err
                            else{

                                //console.log(student.length)
                                var value = req.body.note
                                var id_student = req.params.id
                                var name_student = student.fullname
                                var module = data.teacher.codeModule
        
                                var note = new Note({
                                    id_student: id_student,
                                    name_student:name_student,
                                    module: module,
                                    value: value
                                })
        
                                note.save((err) => {
                                    if (err) {
                                        console.log(err)
                                    } else {
                                        req.flash('success', 'note added...')
                                        res.redirect('/students')
                                    }
                                })
                            }
                        })
                    }
                }
            })

        }
    })

}

exports.put_note = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            var value = req.body.note
            var note = {}
            note.value = value

            var query = { _id: req.params.id }
            Note.update(query, note, (err) => {
                if (err) console.log(err)
                else {
                    req.flash('success', 'note updated..')
                    res.redirect(303,'/students')
                }
            })

        }
    })
}

exports.delete_note = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            // res.setHeader('Authorization', req.token)
            res.locals.user = data
            res.locals.nmbrRec = req.cookies['nmbrRec']

            var query = { _id: req.params.id }
            Note.remove(query, (err) => {
                if (err) console.log(err)
                else {
                    req.flash('success', 'note deleted...')
                    res.redirect(303,'/students')
                }
            })
        }
    })
}