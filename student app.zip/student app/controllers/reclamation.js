var jwt = require('jsonwebtoken')

var Reclamation = require('../models/reclamation')


exports.reclamation = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/dashboard')
        } else {
            if (data.student) {
                req.flash('danger', 'you dont have permission')
                res.redirect('/')
            }
            if(data.teacher.isResp==1){

                res.locals.user = data
                res.locals.nmbrRec = req.cookies['nmbrRec']
    
                Reclamation.findById(req.params.id, (err, reclamation) => {
                    if (err) {
                        req.flash('warning', 'internal server error...try again later plz !')
                        res.status(500).redirect('/responsible')
                    } else {
                        res.status(200).render('responsible/reclamation', {
                            reclamation: reclamation
                        })
                    }
                })
            }else{
                res.locals.user = data
                res.locals.nmbrRec = req.cookies['nmbrRec']

                Reclamation.findById(req.params.id, (err, reclamation) => {
                    if (err) {
                        console.log(err)
                    } else {
                        res.render('teacher/reclamation', {
                            reclamation: reclamation
                        })
                    }
                })
            }
        }
    })
}

exports.delete_reclamation = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if(data.teacher.isResp==1){

                res.locals.user = data
                res.locals.nmbrRec = req.cookies['nmbrRec']
    
                var query = { _id: req.params.id }
                Reclamation.remove(query, (err) => {
                    if (err) {
                        req.flash('warning', 'internal server error...try again later plz !')
                        res.status(500).redirect('/dashboard')
                    }
                    else {
                        Reclamation.find({ owner: "responsible" }, (err, reclamations) => {
    
                            if (err) {
                                req.flash('warning', 'internal server error...try again later plz !')
                                res.status(500).redirect('/dashboard')
                            }
                            else {
                                nbr = reclamations.length
                                req.session.nbmrRec = nbr
                                req.flash('info', 'reclamation deleted..')
                                res.redirect(303, '/reclamations')
                            }
                        })
    
                    }
                })
            }else{
                res.locals.user = data
                res.locals.nmbrRec = req.cookies['nmbrRec']

                var query = { _id: req.params.id }
                Reclamation.remove(query, (err) => {
                    if (err) throw err
                    else {
                        Reclamation.find({ owner: "teacher", to: data.teacher.fullname }, (err, reclamations) => {

                            if (err) throw err
                            else {
                                nbr = reclamations.length
                                req.session.nbmrRec = nbr
                                req.flash('info', 'reclamation deleted..')
                                res.redirect(303,'/reclamations')
                            }
                        })

                    }
                })
            }
        }
    })
}

exports.responsible_reclamation = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            if (!data.student) {
                req.flash('danger', 'you dont have permission')
                res.redirect('/')
            }
            res.locals.user = data
            res.render('student/responsible_reclamation')
        }
    })
}

//teacher reclamation page
exports.teacher_reclamation = (req, res) => {

    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/dashboard')
        } else {
            if (!data.student) {
                req.flash('danger', 'you dont have permission')
                res.redirect('/')
            }
            res.locals.user = data
            Teacher.find({ isResp: 0 }, (err, teachers) => {
                if (err) throw err
                else {
                    res.render('student/teacher_reclamation', { teachers: teachers })
                }
            })
        }
    })
}

exports.post_responsible_reclamation = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/')
        } else {
            res.locals.user = data

            var name = data.student.fullname
            var filiere = data.student.filiere
            var body = req.body.reclamation_body
            var owner = "responsible"


            var reclamation = new Reclamation({
                name: name,
                filiere: filiere,
                body: body,
                owner: owner
            })

            reclamation.save((err) => {
                if (err) {
                    req.flash('danger', 'failed to send reclamation...try again ')
                    res.redirect('/reclamation/responsible')
                } else {
                    req.flash('success', 'reclamation send with success...')
                    res.redirect('/dashboard')
                }
            })
        }
    })
}

//teacher reclamation
exports.post_teacher_reclamation = (req, res) => {
    jwt.verify(req.cookies['token'], 'secretkey', (err, data) => {
        if (err) {
            console.log(err)
            req.flash('danger', 'you need to be loged in')
            res.redirect('/dashboard')
        } else {
            res.locals.user = data

            var name = data.student.fullname
            var filiere = data.student.filiere
            var body = req.body.reclamation_body
            var owner = "teacher"
            var to = req.body.teacher_name


            var reclamation = new Reclamation({
                name: name,
                filiere: filiere,
                body: body,
                owner: owner,
                to: to
            })

            reclamation.save((err) => {
                if (err) {
                    req.flash('danger', 'failed to send reclamation...try again ')
                    res.redirect('/reclamation/responsible')
                } else {
                    req.flash('success', 'reclamation send with success...')
                    res.redirect('/dashboard')
                }
            })
        }
    })
}


