module.exports = {
    database: 'mongodb://localhost/studentRestApp',
    secret: 'privatesecretkey'
}